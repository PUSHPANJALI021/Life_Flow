/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter } from 'react-router-dom';
import { AppProvider, RoleProvider } from './context/AppContext';
import AppRouter from './router/AppRouter';

export default function App() {
  return (
    <AppProvider>
      <RoleProvider>
        <BrowserRouter>
          <AppRouter />
        </BrowserRouter>
      </RoleProvider>
    </AppProvider>
  );
}

