import React, { createContext, useContext, useState, ReactNode } from 'react';
import { useSimulation } from '../hooks/useSimulation';

interface AppContextType {
  units: any[];
  facilities: any[];
  alerts: any[];
  transfers: any[];
  time: Date;
  setUnits: (units: any[]) => void;
  setTransfers: (transfers: any[]) => void;
  setAlerts: (alerts: any[]) => void;
  addUnit: (unit: any) => void;
  approveTransfer: (unitId: string, destId: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const simulation = useSimulation();

  const addUnit = (unit: any) => {
    simulation.setUnits((prev: any[]) => [unit, ...prev]);
  };

  const approveTransfer = (unitId: string, destId: string) => {
    simulation.setUnits((prev: any[]) => prev.map(u => 
      u.id === unitId ? { ...u, status: 'in_transfer' } : u
    ));
    
    // Add to transfers
    const unit = simulation.units.find((u: any) => u.id === unitId);
    const newTransfer = {
      id: `TR-${Date.now()}`,
      unitId: unitId,
      bloodGroup: unit?.bloodGroup || 'O+',
      sourceFacilityId: unit?.facilityId || 'FAC-001',
      destinationFacilityId: destId,
      status: 'approved',
      eta: 15,
      ambulanceId: 'AMB-' + (100 + Math.floor(Math.random() * 900)),
      lat: 28.5672,
      lng: 77.2100,
      path: [[28.5672, 77.2100], [28.5284, 77.2185]]
    };
    simulation.setTransfers((prev: any[]) => [newTransfer, ...prev]);
  };
  
  return (
    <AppContext.Provider value={{ ...simulation, addUnit, approveTransfer }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useAppContext must be used within AppProvider');
  return context;
};

type Role = 'Blood Bank Operator' | 'Hospital Transfusion Desk' | 'District Admin';

interface RoleContextType {
  role: Role;
  setRole: (role: Role) => void;
}

const RoleContext = createContext<RoleContextType | undefined>(undefined);

export const RoleProvider = ({ children }: { children: ReactNode }) => {
  const [role, setRole] = useState<Role>('District Admin');

  return (
    <RoleContext.Provider value={{ role, setRole }}>
      {children}
    </RoleContext.Provider>
  );
};

export const useRoleContext = () => {
  const context = useContext(RoleContext);
  if (!context) throw new Error('useRoleContext must be used within RoleProvider');
  return context;
};
