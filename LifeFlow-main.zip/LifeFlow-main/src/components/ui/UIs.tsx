import React from 'react';
import { motion } from 'motion/react';
import { cn } from '../../utils/utils';

interface BadgeProps {
  label: string;
  variant?: 'safe' | 'watch' | 'urgent' | 'critical' | 'info' | 'default';
  className?: string;
  dot?: boolean;
}

export const Badge = ({ label, variant = 'default', className, dot }: BadgeProps) => {
  const variants = {
    safe: 'bg-safe/10 text-safe border-safe/20',
    watch: 'bg-watch/10 text-watch border-watch/20',
    urgent: 'bg-urgent/10 text-urgent border-urgent/20',
    critical: 'bg-critical/10 text-critical border-critical/20 pulse-critical',
    info: 'bg-blue-400/10 text-blue-400 border-blue-400/20',
    default: 'bg-navy-800 text-gray-400 border-navy-700'
  };

  return (
    <div className={cn(
      "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold border uppercase tracking-wider",
      variants[variant],
      className
    )}>
      {dot && <div className={cn("w-1.5 h-1.5 rounded-full", variant === 'critical' ? 'bg-white' : `bg-current`)} />}
      {label}
    </div>
  );
};

interface CardProps {
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
  className?: string;
  headerAction?: React.ReactNode;
}

export const Card = ({ children, title, subtitle, className, headerAction }: CardProps) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn("bg-navy-900/50 backdrop-blur-sm border border-navy-800 rounded-xl overflow-hidden flex flex-col", className)}
    >
      {(title || subtitle) && (
        <div className="p-4 border-b border-navy-800 flex items-center justify-between">
          <div>
            {title && <h3 className="text-sm font-display font-semibold tracking-wide uppercase text-gray-300">{title}</h3>}
            {subtitle && <p className="text-[10px] font-mono text-gray-500 uppercase tracking-tighter mt-0.5">{subtitle}</p>}
          </div>
          {headerAction}
        </div>
      )}
      <div className="flex-1">
        {children}
      </div>
    </motion.div>
  );
};

export const Button = ({ 
  children, 
  variant = 'primary', 
  className,
  ...props 
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'outline' | 'danger' }) => {
  const variants = {
    primary: 'bg-blue-600 hover:bg-blue-500 text-white',
    secondary: 'bg-indigo-600 hover:bg-indigo-500 text-white',
    outline: 'border border-navy-700 bg-transparent hover:bg-navy-800 text-gray-300',
    danger: 'bg-blood-red hover:bg-red-500 text-white'
  };

  return (
    <button 
      className={cn(
        "px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 active:scale-95 disabled:opacity-50 inline-flex items-center justify-center gap-2",
        variants[variant],
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
};
