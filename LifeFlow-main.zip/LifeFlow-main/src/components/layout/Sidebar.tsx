import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Database, 
  Route, 
  TrendingUp, 
  Truck, 
  Bell, 
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
  Circle
} from 'lucide-react';
import { cn } from '../../utils/utils';
import { useRoleContext } from '../../context/AppContext';

interface SidebarProps {
  collapsed: boolean;
  setCollapsed: (collapsed: boolean) => void;
}

const Sidebar = ({ collapsed, setCollapsed }: SidebarProps) => {
  const { role } = useRoleContext();

  const menuItems = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard, roles: ['Blood Bank Operator', 'Hospital Transfusion Desk', 'District Admin'] },
    { name: 'Inventory', path: '/inventory', icon: Database, roles: ['Blood Bank Operator', 'District Admin'] },
    { name: 'Expiry Routing', path: '/expiry-routing', icon: Route, roles: ['Blood Bank Operator', 'District Admin'] },
    { name: 'Demand Forecast', path: '/demand-forecast', icon: TrendingUp, roles: ['Hospital Transfusion Desk', 'District Admin'] },
    { name: 'Transfers', path: '/transfers', icon: Truck, roles: ['Hospital Transfusion Desk', 'District Admin'] },
    { name: 'Alerts', path: '/alerts', icon: Bell, roles: ['Blood Bank Operator', 'Hospital Transfusion Desk', 'District Admin'] },
    { name: 'Admin', path: '/admin', icon: ShieldCheck, roles: ['District Admin'] },
  ];

  const filteredItems = menuItems.filter(item => item.roles.includes(role));

  return (
    <aside 
      className={cn(
        "bg-navy-900 border-r border-navy-800 transition-all duration-300 flex flex-col h-screen sticky top-0",
        collapsed ? "w-20" : "w-64"
      )}
    >
      <div className="p-6 flex items-center justify-between">
        {!collapsed && (
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-blood-red flex items-center justify-center">
              <div className="w-4 h-4 rounded-full bg-white animate-pulse" />
            </div>
            <span className="font-display text-xl font-bold tracking-tight">LifeFlow</span>
          </div>
        )}
        <button 
          onClick={() => setCollapsed(!collapsed)}
          className="p-2 rounded-lg hover:bg-navy-800 transition-colors"
        >
          {collapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
        </button>
      </div>

      <nav className="flex-1 px-3 space-y-2 py-4">
        {filteredItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) => cn(
              "flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-200 group relative",
              isActive 
                ? "bg-navy-800 text-blue-400 border-l-2 border-blue-400" 
                : "text-gray-400 hover:bg-navy-800/50 hover:text-gray-200"
            )}
          >
            <item.icon size={20} />
            {!collapsed && <span className="font-medium font-display">{item.name}</span>}
            
            {collapsed && (
              <div className="absolute left-16 bg-navy-800 px-2 py-1 rounded text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50">
                {item.name}
              </div>
            )}
          </NavLink>
        ))}
      </nav>

      <div className="p-4 border-t border-navy-800">
        <div className="flex items-center gap-2 text-safe text-xs px-2 mb-4">
          <Circle size={8} fill="currentColor" className="animate-pulse" />
          {!collapsed && <span className="font-mono tracking-widest uppercase">System Live</span>}
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
