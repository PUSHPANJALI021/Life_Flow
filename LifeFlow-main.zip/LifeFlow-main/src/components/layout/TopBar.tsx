import React from 'react';
import { Search, Bell, User } from 'lucide-react';
import { useRoleContext } from '../../context/AppContext';

const TopBar = () => {
  const { role, setRole } = useRoleContext();

  const roles = ['Blood Bank Operator', 'Hospital Transfusion Desk', 'District Admin'];

  return (
    <header className="h-16 bg-navy-950/80 backdrop-blur-md border-b border-navy-800 sticky top-0 z-40 px-6 flex items-center justify-between">
      <div className="flex-1 max-w-xl">
        <div className="relative group">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-blue-400 transition-colors" size={18} />
          <input 
            type="text" 
            placeholder="Search units, facilities, or alerts..." 
            className="w-full bg-navy-900 border border-navy-800 rounded-full py-2 pl-10 pr-4 text-sm focus:outline-none focus:ring-1 focus:ring-blue-400/50 focus:border-blue-400 transition-all font-sans"
          />
        </div>
      </div>

      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2">
          <span className="text-xs text-gray-400 font-mono uppercase tracking-tighter">View As</span>
          <select 
            value={role} 
            onChange={(e) => setRole(e.target.value as any)}
            className="bg-navy-900 border border-navy-800 text-xs rounded px-2 py-1 focus:outline-none focus:border-blue-400 text-blue-400 font-medium"
          >
            {roles.map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>

        <div className="relative">
          <Bell className="text-gray-400 hover:text-white cursor-pointer transition-colors" size={20} />
          <span className="absolute -top-1 -right-1 w-2 h-2 bg-blood-red rounded-full animate-ping" />
          <span className="absolute -top-1 -right-1 w-2 h-2 bg-blood-red rounded-full" />
        </div>

        <div className="flex items-center gap-3 border-l border-navy-800 pl-6 cursor-pointer group">
          <div className="w-8 h-8 rounded-full bg-navy-800 flex items-center justify-center border border-navy-700 group-hover:border-blue-400 transition-colors">
            <User size={16} className="text-gray-400 group-hover:text-blue-400" />
          </div>
          <div className="hidden lg:block text-left">
            <p className="text-sm font-medium text-gray-200">Rahul Sharma</p>
            <p className="text-[10px] text-gray-500 font-mono uppercase tracking-tight">AIIMS Delhi</p>
          </div>
        </div>
      </div>
    </header>
  );
};

export default TopBar;
