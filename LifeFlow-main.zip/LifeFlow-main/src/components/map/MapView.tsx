import React from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, CircleMarker } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix for default marker icons in Leaflet
const DefaultIcon = L.icon({
    iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
    shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});
L.Marker.prototype.options.icon = DefaultIcon;

import { useAppContext } from '../../context/AppContext';

const MapView = () => {
    const { facilities, transfers } = useAppContext();
    const center: [number, number] = [28.5672, 77.2100]; // Delhi center

    return (
        <div className="w-full h-full relative">
            <MapContainer 
                center={center} 
                zoom={12} 
                className="w-full h-full bg-navy-950"
                zoomControl={false}
            >
                <TileLayer
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />

                {facilities.map((fac) => {
                    const healthColors = {
                        stable: '#10B981',
                        low: '#F59E0B',
                        critical: '#DC2626'
                    };

                    return (
                        <CircleMarker
                            key={fac.id}
                            center={[fac.lat, fac.lng]}
                            pathOptions={{ 
                                color: healthColors[fac.stockHealth],
                                fillColor: healthColors[fac.stockHealth],
                                fillOpacity: 0.6,
                                weight: 2
                            }}
                            radius={8}
                        >
                            <Popup>
                                <div className="p-2 min-w-40 font-sans">
                                    <h4 className="font-bold text-navy-900">{fac.name}</h4>
                                    <p className="text-xs text-navy-700 capitalize mb-2">{fac.type} • {fac.district}</p>
                                    <div className="flex flex-col gap-1">
                                        <div className="flex justify-between text-[10px]">
                                            <span className="text-gray-500 font-mono">STOCK HEALTH</span>
                                            <span className="font-bold" style={{ color: healthColors[fac.stockHealth] }}>{fac.stockHealth.toUpperCase()}</span>
                                        </div>
                                        <div className="flex justify-between text-[10px]">
                                            <span className="text-gray-500 font-mono">OCCUPANCY</span>
                                            <span className="font-bold text-navy-800">{fac.currentUnits}/{fac.capacity}</span>
                                        </div>
                                    </div>
                                </div>
                            </Popup>
                        </CircleMarker>
                    );
                })}

                {transfers.map((tr) => (
                    <React.Fragment key={tr.id}>
                        <Polyline 
                            positions={tr.path} 
                            pathOptions={{ color: '#3B82F6', weight: 2, dashArray: '5, 10' }} 
                        />
                        <CircleMarker 
                            center={[tr.lat, tr.lng]} 
                            radius={6}
                            pathOptions={{ color: '#FFFFFF', fillColor: '#3B82F6', fillOpacity: 1, weight: 2 }}
                        >
                            <Popup>
                                <div className="p-2 font-mono text-xs">
                                    <p className="font-bold text-blue-600">AMBULANCE: {tr.ambulanceId}</p>
                                    <p className="text-gray-600 mt-1">UNIT: {tr.unitId} ({tr.bloodGroup})</p>
                                    <p className="text-gray-600">ETA: {tr.eta} MIN</p>
                                </div>
                            </Popup>
                        </CircleMarker>
                    </React.Fragment>
                ))}
            </MapContainer>

            {/* Custom Legend */}
            <div className="absolute bottom-4 left-4 z-[1000] bg-navy-900/90 border border-navy-800 p-3 rounded-lg backdrop-blur-md">
               <h5 className="text-[10px] font-mono text-gray-500 uppercase tracking-widest mb-2 font-bold">Facility Pulse</h5>
               <div className="space-y-1.5">
                  {[
                     { label: 'Critical', color: 'bg-critical' },
                     { label: 'Low', color: 'bg-watch' },
                     { label: 'Stable', color: 'bg-safe' },
                  ].map(l => (
                     <div key={l.label} className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${l.color}`} />
                        <span className="text-[10px] text-gray-400 font-display font-medium">{l.label}</span>
                     </div>
                  ))}
               </div>
            </div>
        </div>
    );
};

export default MapView;
