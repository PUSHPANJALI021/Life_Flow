import React, { useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Sidebar from '../components/layout/Sidebar';
import TopBar from '../components/layout/TopBar';

// Lazy load or just import for now
import Dashboard from '../pages/Dashboard';
import Inventory from '../pages/Inventory';
import ExpiryRouting from '../pages/ExpiryRouting';
import DemandForecast from '../pages/DemandForecast';
import Transfers from '../pages/Transfers';
import Alerts from '../pages/Alerts';
import Admin from '../pages/Admin';

const AppRouter = () => {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className="flex min-h-screen bg-navy-950 overflow-hidden">
      <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} />
      
      <main className="flex-1 flex flex-col min-h-screen overflow-hidden">
        <TopBar />
        
        <div className="flex-1 overflow-y-auto custom-scrollbar">
          <div className="p-6 max-w-[1600px] mx-auto">
            <Routes>
              <Route path="/" element={<Navigate to="/dashboard" />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/inventory" element={<Inventory />} />
              <Route path="/expiry-routing" element={<ExpiryRouting />} />
              <Route path="/demand-forecast" element={<DemandForecast />} />
              <Route path="/transfers" element={<Transfers />} />
              <Route path="/alerts" element={<Alerts />} />
              <Route path="/admin" element={<Admin />} />
            </Routes>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AppRouter;
