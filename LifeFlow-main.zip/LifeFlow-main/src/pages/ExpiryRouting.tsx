import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Route as RouteIcon, MapPin, Zap, ArrowRight, CheckCircle2 } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { Card, Badge, Button } from '../components/ui/UIs';
import MapView from '../components/map/MapView';
import { cn } from '../utils/utils';

const ExpiryRouting = () => {
  const { units, facilities, time, approveTransfer } = useAppContext();
  const [selectedUnit, setSelectedUnit] = useState<any>(null);

  const expiringUnits = units
    .filter(u => {
      const hoursRemaining = (new Date(u.expiresAt).getTime() - time.getTime()) / (1000 * 60 * 60);
      return hoursRemaining < 24 && u.status !== 'in_transfer';
    })
    .sort((a,b) => new Date(a.expiresAt).getTime() - new Date(b.expiresAt).getTime());

  if (selectedUnit === null && expiringUnits.length > 0) {
      setSelectedUnit(expiringUnits[0]);
  }

  const handleApprove = () => {
     if (selectedUnit) {
        approveTransfer(selectedUnit.id, 'FAC-004');
        setSelectedUnit(null);
     }
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-display font-bold">Expiry Routing Intelligence</h1>
        <p className="text-gray-500 font-mono text-xs uppercase tracking-widest mt-1">Autonomous Redistribution Algorithms at Work</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-[calc(100vh-220px)]">
        {/* Left Panel: Ranked Units */}
        <div className="lg:col-span-4 flex flex-col gap-4 overflow-hidden">
           <div className="flex items-center justify-between px-1">
              <h3 className="text-xs font-mono text-gray-500 uppercase tracking-widest font-bold">Near-Expiry Queue</h3>
              <Badge label={`${expiringUnits.length} Units`} variant="default" />
           </div>

           <div className="flex-1 overflow-y-auto space-y-3 pr-2 custom-scrollbar">
              {expiringUnits.map(unit => {
                 const hoursRemaining = (new Date(unit.expiresAt).getTime() - time.getTime()) / (1000 * 60 * 60);
                 const h = Math.floor(hoursRemaining);
                 const m = Math.floor((hoursRemaining % 1) * 60);
                 
                 return (
                   <motion.div
                    key={unit.id}
                    onClick={() => setSelectedUnit(unit)}
                    className={cn(
                      "p-4 rounded-xl border transition-all cursor-pointer",
                      selectedUnit?.id === unit.id 
                        ? "bg-navy-900 border-blue-500 shadow-lg shadow-blue-500/10" 
                        : "bg-navy-900/40 border-navy-800 hover:border-navy-700"
                    )}
                   >
                     <div className="flex justify-between items-start mb-3">
                        <div className="flex items-center gap-3">
                           <div className="w-10 h-10 rounded bg-navy-950 border border-navy-800 flex flex-col items-center justify-center">
                              <span className="text-xs font-bold text-gray-200">{unit.bloodGroup}</span>
                              <span className="text-[8px] font-mono text-gray-500 uppercase leading-none">RBC</span>
                           </div>
                           <div>
                              <p className="text-xs font-bold text-gray-200">{unit.id}</p>
                              <p className="text-[10px] text-gray-500 font-mono uppercase">Current: AIIMS Delhi</p>
                           </div>
                        </div>
                        <Badge label={`${h}H ${m}M`} variant={h < 4 ? "critical" : "watch"} />
                     </div>

                     <div className="flex items-center justify-between text-[10px] font-mono">
                        <span className="text-gray-500 uppercase">Demand Match Score</span>
                        <div className="flex items-center gap-2">
                           <div className="w-16 h-1 bg-navy-800 rounded-full overflow-hidden">
                              <div className="h-full bg-safe" style={{ width: `${unit.routingScore}%` }} />
                           </div>
                           <span className="font-bold text-safe">{unit.routingScore}%</span>
                        </div>
                     </div>
                   </motion.div>
                 );
              })}
           </div>
        </div>

        {/* Right Panel: Route Map & Details */}
        <div className="lg:col-span-8 flex flex-col gap-6">
           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card title="Analysis & Recommendation" className="bg-navy-900/80">
                 <div className="p-4 space-y-4">
                    <div className="flex items-center gap-4 py-2 border-b border-navy-800">
                       <Zap size={20} className="text-watch" />
                       <div>
                          <p className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">Recommended Action</p>
                          <p className="text-sm font-medium text-gray-200">Urgent Redistribution to Safdarjung Hospital</p>
                       </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                       <div className="bg-navy-950/50 p-3 rounded-lg border border-navy-800">
                          <p className="text-[10px] font-mono text-gray-500 uppercase tracking-tighter mb-1">Impact Score</p>
                          <p className="text-lg font-display font-bold text-safe">High</p>
                          <p className="text-[9px] text-gray-600 mt-0.5">Prevents imminent shortage</p>
                       </div>
                       <div className="bg-navy-950/50 p-3 rounded-lg border border-navy-800">
                          <p className="text-[10px] font-mono text-gray-500 uppercase tracking-tighter mb-1">Time To Site</p>
                          <p className="text-lg font-display font-bold text-blue-400">14 MIN</p>
                          <p className="text-[9px] text-gray-600 mt-0.5">Ambulance AMB-101 nearby</p>
                       </div>
                    </div>

                    <div className="flex items-center gap-3">
                       <CheckCircle2 size={16} className="text-safe" />
                       <span className="text-xs text-gray-400">Validated against real-time OT schedule at AIIMS</span>
                    </div>

                    <Button 
  variant="primary" 
  className="w-full mt-2 h-12 flex items-center justify-center gap-3 font-display uppercase tracking-widest"
  onClick={handleApprove}
  disabled={!selectedUnit}
>
  <RouteIcon size={18} />
  Approve & Dispatch Transfer
</Button>
                 </div>
              </Card>

              <Card title="Routing Intelligence" className="bg-navy-900/80">
                 <div className="p-4 space-y-4">
                    <div className="flex items-center justify-between">
                       <div className="flex items-center gap-3">
                          <MapPin size={16} className="text-blue-500" />
                          <span className="text-xs font-mono text-gray-400">SOURCE: AIIMS Delhi</span>
                       </div>
                    </div>
                    <div className="w-full h-8 flex items-center justify-center">
                       <div className="w-px h-full border-l border-dashed border-navy-700" />
                    </div>
                    <div className="flex items-center justify-between">
                       <div className="flex items-center gap-3">
                          <div className="w-4 h-4 rounded-full bg-urgent animate-ping absolute" />
                          <MapPin size={16} className="text-urgent relative" />
                          <span className="text-xs font-mono text-gray-400">DEST: Safdarjung Hospital</span>
                       </div>
                    </div>

                    <div className="bg-navy-950/50 p-3 rounded-lg border border-navy-800 space-y-2 mt-4">
                       <p className="text-[10px] font-mono text-gray-500 uppercase tracking-widest text-center">Confidence Pulse</p>
                       <div className="flex gap-1 h-3">
                          {[1,2,3,4,5,6,7,8,9,10,11,12].map(i => (
                             <div key={i} className={cn("flex-1 rounded-sm", i < 9 ? "bg-safe/60" : "bg-navy-800")} />
                          ))}
                       </div>
                       <p className="text-[9px] text-gray-600 text-center font-mono uppercase tracking-widest">Calculated across 12 infrastructure variables</p>
                    </div>
                 </div>
              </Card>
           </div>

           <div className="flex-1 rounded-xl overflow-hidden border border-navy-800 relative group">
              <MapView />
           </div>
        </div>
      </div>
    </div>
  );
};

export default ExpiryRouting;
