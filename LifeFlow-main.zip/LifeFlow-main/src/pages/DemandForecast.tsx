import React from 'react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell
} from 'recharts';
import { TrendingUp, AlertTriangle, Layers, Calendar } from 'lucide-react';
import { Card, Badge, Button } from '../components/ui/UIs';
import { cn } from '../utils/utils';

const data = [
  { time: '08:00', demand: 45, supply: 60, confidence: [40, 50] },
  { time: '10:00', demand: 52, supply: 58, confidence: [45, 59] },
  { time: '12:00', demand: 85, supply: 55, confidence: [75, 95] },
  { time: '14:00', demand: 95, supply: 50, confidence: [85, 105] },
  { time: '16:00', demand: 70, supply: 48, confidence: [60, 80] },
  { time: '18:00', demand: 55, supply: 45, confidence: [45, 65] },
  { time: '20:00', demand: 40, supply: 42, confidence: [30, 50] },
  { time: '22:00', demand: 30, supply: 40, confidence: [20, 40] },
];

const bloodGroupData = [
  { name: 'O+', intensity: 85, status: 'high' },
  { name: 'O-', intensity: 65, status: 'medium' },
  { name: 'A+', intensity: 45, status: 'medium' },
  { name: 'A-', intensity: 30, status: 'low' },
  { name: 'B+', intensity: 92, status: 'critical' },
  { name: 'B-', intensity: 20, status: 'low' },
  { name: 'AB+', intensity: 15, status: 'low' },
  { name: 'AB-', intensity: 10, status: 'low' },
];

const DemandForecast = () => {
  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-display font-bold">Demand Intelligence</h1>
          <p className="text-gray-500 font-mono text-xs uppercase tracking-widest mt-1">Predictive analysis for regional consumption trends</p>
        </div>
        <div className="flex bg-navy-900 border border-navy-800 rounded-lg p-1">
           {['6H', '12H', '24H', '72H'].map(t => (
             <button key={t} className={cn(
                "px-4 py-1 rounded text-[10px] font-mono font-bold tracking-widest uppercase transition-colors",
                t === '24H' ? "bg-blue-600 text-white" : "text-gray-500 hover:text-gray-300"
             )}>
                {t}
             </button>
           ))}
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Main Forecast Chart */}
        <div className="lg:col-span-8">
           <Card title="Consumption Forecast (24h Window)" subtitle="Volume predictions vs Inventory baseline" className="h-[400px]">
              <div className="h-[320px] w-full p-4">
                 <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={data}>
                       <defs>
                          <linearGradient id="colorDemand" x1="0" y1="0" x2="0" y2="1">
                             <stop offset="5%" stopColor="#EF4444" stopOpacity={0.3}/>
                             <stop offset="95%" stopColor="#EF4444" stopOpacity={0}/>
                          </linearGradient>
                          <linearGradient id="colorSupply" x1="0" y1="0" x2="0" y2="1">
                             <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.3}/>
                             <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                          </linearGradient>
                       </defs>
                       <CartesianGrid strokeDasharray="3 3" stroke="#1E2A3A" vertical={false} />
                       <XAxis 
                        dataKey="time" 
                        stroke="#4B5563" 
                        fontSize={10} 
                        fontFamily="IBM Plex Mono"
                        tickLine={false}
                        axisLine={false}
                       />
                       <YAxis 
                        stroke="#4B5563" 
                        fontSize={10} 
                        fontFamily="IBM Plex Mono"
                        tickLine={false}
                        axisLine={false}
                       />
                       <Tooltip 
                        contentStyle={{ backgroundColor: '#111827', borderColor: '#1E2A3A', color: '#F9FAFB' }}
                        itemStyle={{ fontSize: '10px', fontFamily: 'IBM Plex Mono' }}
                       />
                       <Area 
                        type="monotone" 
                        dataKey="demand" 
                        stroke="#EF4444" 
                        fillOpacity={1} 
                        fill="url(#colorDemand)" 
                        strokeWidth={2}
                       />
                       <Area 
                        type="monotone" 
                        dataKey="supply" 
                        stroke="#3B82F6" 
                        fillOpacity={1} 
                        fill="url(#colorSupply)" 
                        strokeWidth={2}
                        strokeDasharray="5 5"
                       />
                    </AreaChart>
                 </ResponsiveContainer>
              </div>
              <div className="px-6 flex gap-6 pb-2">
                 <div className="flex items-center gap-2">
                    <div className="w-3 h-0.5 bg-urgent" />
                    <span className="text-[10px] font-mono text-gray-500 uppercase">Predicted Demand</span>
                 </div>
                 <div className="flex items-center gap-2">
                    <div className="w-3 h-0.5 bg-blue-500 border-dashed border-t-2" />
                    <span className="text-[10px] font-mono text-gray-500 uppercase">Projected Supply</span>
                 </div>
              </div>
           </Card>
        </div>

        {/* Group Intensity */}
        <div className="lg:col-span-4">
           <Card title="Demand Intensity by Group" subtitle="Predicted volume by blood type" className="h-[400px]">
              <div className="h-[320px] w-full p-4">
                 <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={bloodGroupData} layout="vertical" margin={{ left: 10, right: 30 }}>
                       <XAxis type="number" hide />
                       <YAxis 
                        dataKey="name" 
                        type="category" 
                        stroke="#9CA3AF" 
                        fontSize={12} 
                        fontFamily="Rajdhani" 
                        tickLine={false}
                        axisLine={false}
                        width={40}
                       />
                       <Tooltip 
                        cursor={{ fill: '#1E2A3A' }}
                        contentStyle={{ backgroundColor: '#111827', borderColor: '#1E2A3A', color: '#F9FAFB' }}
                       />
                       <Bar dataKey="intensity" radius={[0, 4, 4, 0]} barSize={12}>
                          {bloodGroupData.map((entry, index) => (
                             <Cell key={`cell-${index}`} fill={entry.status === 'critical' ? '#EF4444' : entry.status === 'high' ? '#F59E0B' : '#10B981'} />
                          ))}
                       </Bar>
                    </BarChart>
                 </ResponsiveContainer>
              </div>
              <div className="px-6 space-y-1">
                 <div className="flex justify-between items-center text-[10px] font-mono">
                    <span className="text-gray-500 uppercase">Overall Demand Heat</span>
                    <span className="text-urgent font-bold text-xs">ERRATIC</span>
                 </div>
              </div>
           </Card>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
         <div className="bg-navy-900 border border-navy-800 p-5 rounded-xl flex items-start gap-4">
            <div className="p-3 rounded-lg bg-urgent/10">
               <AlertTriangle className="text-urgent" size={24} />
            </div>
            <div>
               <h4 className="font-display font-bold text-gray-200">Alert: O+ Spike Expected</h4>
               <p className="text-xs text-gray-500 font-sans mt-1 leading-relaxed">
                  Demand for O+ expected to spike +40% in next 6 hours. Correlated with scheduled trauma surgeries at AIIMS Delhi and Safdarjung.
               </p>
               <Button variant="outline" className="mt-4 h-8 text-[10px] py-1 border-urgent/20 text-urgent hover:bg-urgent/10">PRE-ROUTE UNITS</Button>
            </div>
         </div>

         <div className="bg-navy-900 border border-navy-800 p-5 rounded-xl flex items-start gap-4">
            <div className="p-3 rounded-lg bg-safe/10">
               <TrendingUp className="text-safe" size={24} />
            </div>
            <div>
               <h4 className="font-display font-bold text-gray-200">B+ Supply Optimal</h4>
               <p className="text-xs text-gray-500 font-sans mt-1 leading-relaxed">
                  Incoming donations from Red Cross Blood Bank will stabilize B+ levels by 18:00. Current reserves sufficient for projected needs.
               </p>
               <Button variant="outline" className="mt-4 h-8 text-[10px] py-1 border-safe/20 text-safe hover:bg-safe/10">VIEW ARRIVALS</Button>
            </div>
         </div>

         <div className="bg-navy-900 border border-navy-800 p-5 rounded-xl flex items-start gap-4">
            <div className="p-3 rounded-lg bg-blue-400/10">
               <Layers className="text-blue-400" size={24} />
            </div>
            <div>
               <h4 className="font-display font-bold text-gray-200">State Holiday Impact</h4>
               <p className="text-xs text-gray-500 font-sans mt-1 leading-relaxed">
                  Regional holiday on Friday predicted to reduce blood collections by 25%. Suggest early surplus buildup across nodes.
               </p>
               <Button variant="outline" className="mt-4 h-8 text-[10px] py-1 border-blue-400/20 text-blue-400 hover:bg-blue-400/10">SYSTEM ADJUST</Button>
            </div>
         </div>
      </div>
    </div>
  );
};

export default DemandForecast;
