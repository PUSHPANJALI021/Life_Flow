import React from 'react';
import { motion } from 'motion/react';
import { Truck, MapPin, Navigation, Clock, CheckCircle2, ChevronRight, Phone } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { Card, Badge, Button } from '../components/ui/UIs';
import MapView from '../components/map/MapView';
import { cn } from '../utils/utils';

const Transfers = () => {
  const { transfers } = useAppContext();

  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <div>
           <h1 className="text-3xl font-display font-bold">Transfer Operations</h1>
           <p className="text-gray-500 font-mono text-xs uppercase tracking-widest mt-1">Live tracking of logistics and ambulance assets</p>
        </div>
        <Button variant="primary">Dispatch New Asset</Button>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-[calc(100vh-220px)]">
        {/* Left Column: Transfer List */}
        <div className="lg:col-span-4 space-y-4 overflow-y-auto pr-2 custom-scrollbar">
           {transfers.map((tr, i) => (
             <motion.div
              key={tr.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-navy-900 border border-navy-800 rounded-xl overflow-hidden hover:border-blue-500/50 transition-all cursor-pointer group"
             >
               <div className="p-4 border-b border-navy-800 flex justify-between items-center bg-navy-950/30">
                  <div className="flex items-center gap-2">
                     <Truck size={14} className="text-blue-400" />
                     <span className="text-xs font-mono font-bold text-gray-200">{tr.id}</span>
                  </div>
                  <Badge 
                    label={tr.status} 
                    variant={tr.status === 'in_transit' ? 'info' : 'safe'} 
                    dot={tr.status === 'in_transit'} 
                  />
               </div>

               <div className="p-4 space-y-4">
                  <div className="flex items-start gap-3">
                     <div className="w-8 h-8 rounded bg-blood-red/10 border border-blood-red/20 flex flex-col items-center justify-center shrink-0">
                        <span className="text-xs font-bold text-blood-red">{tr.bloodGroup}</span>
                     </div>
                     <div className="flex-1">
                        <div className="flex items-center justify-between">
                           <span className="text-[10px] font-mono text-gray-500 uppercase tracking-tighter">Asset</span>
                           <span className="text-[10px] font-bold text-gray-300">{tr.ambulanceId}</span>
                        </div>
                        <div className="flex items-center justify-between mt-1">
                           <span className="text-[10px] font-mono text-gray-500 uppercase tracking-tighter">ETA Baseline</span>
                           <span className="text-[10px] font-bold text-blue-400">{tr.eta} MINS</span>
                        </div>
                     </div>
                  </div>

                  <div className="space-y-4 relative pl-4 border-l-2 border-navy-800">
                     <div className="relative">
                        <div className="absolute -left-[21px] top-1 w-2 h-2 rounded-full bg-blue-500 border-2 border-navy-900" />
                        <p className="text-[10px] font-mono text-gray-500 uppercase tracking-widest leading-none">Source</p>
                        <p className="text-xs font-medium text-gray-300 mt-0.5">AIIMS Blood Bank (FAC-003)</p>
                     </div>
                     <div className="relative">
                        <div className="absolute -left-[21px] top-1 w-2 h-2 rounded-full bg-urgent border-2 border-navy-900" />
                        <p className="text-[10px] font-mono text-gray-500 uppercase tracking-widest leading-none">Destination</p>
                        <p className="text-xs font-medium text-gray-300 mt-0.5">Safdarjung ER (FAC-004)</p>
                     </div>
                  </div>

                  <div className="pt-2 flex gap-2">
                     <Button variant="outline" className="flex-1 h-8 text-[10px] font-mono">
                        <Phone size={12} /> CALL DRIVER
                     </Button>
                     <Button variant="outline" className="h-8 w-10 px-0">
                        <ChevronRight size={14} />
                     </Button>
                  </div>
               </div>
               
               {/* Progress bar */}
               <div className="h-1 w-full bg-navy-800">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: '65%' }}
                    className="h-full bg-blue-400"
                  />
               </div>
             </motion.div>
           ))}
        </div>

        {/* Right Column: Fleet Map & Details */}
        <div className="lg:col-span-8 flex flex-col gap-6">
           <div className="flex-1 rounded-xl overflow-hidden border border-navy-800 relative z-0">
              <MapView />
              
              {/* Floating Overlay Info */}
              <div className="absolute top-4 right-4 z-10 w-64">
                 <Card title="Live Fleet Telemetry" className="bg-navy-950/90 border-navy-800 shadow-2xl">
                    <div className="p-4 space-y-3">
                       <div className="flex items-center justify-between">
                          <span className="text-[10px] font-mono text-gray-500">ASSETS ACTIVE</span>
                          <span className="text-xs font-bold text-gray-200">2/5</span>
                       </div>
                       <div className="flex items-center justify-between">
                          <span className="text-[10px] font-mono text-gray-500">AVG TRANSIT TIME</span>
                          <span className="text-xs font-bold text-gray-200">18.4m</span>
                       </div>
                       <div className="flex items-center justify-between">
                          <span className="text-[10px] font-mono text-gray-500">FUEL AVG (L/100KM)</span>
                          <span className="text-xs font-bold text-gray-200">12.2</span>
                       </div>
                    </div>
                 </Card>
              </div>
           </div>

           {/* Timeline/Step View for Selected Transfer */}
           <div className="h-32 bg-navy-900/50 border border-navy-800 rounded-xl p-4">
              <div className="flex items-center justify-around h-full">
                 {[
                    { label: 'Recommended', status: 'done', time: '14:20' },
                    { label: 'Approved', status: 'done', time: '14:22' },
                    { label: 'Dispatched', status: 'done', time: '14:28' },
                    { label: 'In Transit', status: 'active', time: '14:35' },
                    { label: 'Delivered', status: 'pending', time: '--:--' },
                 ].map((step, i) => (
                    <div key={i} className="flex flex-col items-center gap-2 relative">
                        {i < 4 && (
                           <div className={cn(
                              "absolute top-4 left-1/2 w-full h-[2px]",
                              step.status === 'done' ? "bg-blue-600" : "bg-navy-800"
                           )} />
                        )}
                        <div className={cn(
                           "w-8 h-8 rounded-full border-2 flex items-center justify-center relative z-10",
                           step.status === 'done' ? "bg-blue-600 border-blue-600 text-white" : 
                           step.status === 'active' ? "bg-navy-900 border-blue-400 text-blue-400 pulse-critical" : 
                           "bg-navy-950 border-navy-800 text-gray-600"
                        )}>
                           {step.status === 'done' ? <CheckCircle2 size={16} /> : <div className="text-[10px] font-bold">{i+1}</div>}
                        </div>
                        <div className="text-center">
                           <p className={cn("text-[10px] font-display font-medium uppercase tracking-widest", step.status === 'active' ? 'text-blue-400' : 'text-gray-500')}>
                              {step.label}
                           </p>
                           <p className="text-[8px] font-mono text-gray-600">{step.time}</p>
                        </div>
                    </div>
                 ))}
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Transfers;
