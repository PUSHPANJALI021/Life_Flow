import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Filter, ArrowUpDown, MoreVertical } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { Card, Badge, Button } from '../components/ui/UIs';
import { cn } from '../utils/utils';

const Inventory = () => {
  const { units, facilities, time, addUnit } = useAppContext();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGroup, setSelectedGroup] = useState('All');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  const bloodGroups = ['All', 'O+', 'O-', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-'];

  const filteredUnits = units.filter(u => {
    const matchesSearch = u.id.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         u.bloodGroup.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesGroup = selectedGroup === 'All' || u.bloodGroup === selectedGroup;
    return matchesSearch && matchesGroup;
  }).sort((a, b) => new Date(a.expiresAt).getTime() - new Date(b.expiresAt).getTime());

  const handleAddStock = () => {
     const newUnit = {
        id: `BU-2024-${String(units.length + 1).padStart(3, '0')}`,
        bloodGroup: selectedGroup === 'All' ? 'O+' : selectedGroup,
        component: "Whole Blood",
        collectedAt: new Date().toISOString(),
        expiresAt: new Date(Date.now() + 72 * 60 * 60 * 1000).toISOString(),
        facilityId: "FAC-001",
        status: "available",
        routingScore: 85,
        districtId: "DL-01"
     };
     addUnit(newUnit);
     setIsAddModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold">Live Inventory</h1>
          <p className="text-gray-500 font-mono text-xs uppercase tracking-widest mt-1">Real-time stock across regional node center</p>
        </div>
        
        <div className="flex items-center gap-2">
           <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={16} />
              <input 
                type="text" 
                placeholder="Search Unit ID..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-navy-900 border border-navy-800 rounded-lg py-2 pl-9 pr-4 text-sm focus:outline-none focus:border-blue-400 w-48"
              />
           </div>
           <Button variant="outline" className="h-10">
              <Filter size={16} />
              Filter
           </Button>
           <Button variant="primary" className="h-10" onClick={() => setIsAddModalOpen(true)}>
              Add Stock
           </Button>
        </div>
      </header>

      {/* Add Stock Modal Placeholder (Simple Overlay) */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}
            className="bg-navy-900 border border-navy-800 p-6 rounded-2xl w-full max-w-md shadow-2xl"
          >
            <h2 className="text-xl font-display font-bold mb-4">Quick Stock Injection</h2>
            <div className="space-y-4">
               <div>
                  <label className="text-[10px] font-mono text-gray-500 uppercase">Blood Group</label>
                  <select className="w-full bg-navy-950 border border-navy-800 rounded p-2 text-sm mt-1 focus:border-blue-400 outline-none">
                     {bloodGroups.filter(g => g !== 'All').map(g => <option key={g} value={g}>{g}</option>)}
                  </select>
               </div>
               <div>
                  <label className="text-[10px] font-mono text-gray-500 uppercase">Component Type</label>
                  <select className="w-full bg-navy-950 border border-navy-800 rounded p-2 text-sm mt-1 focus:border-blue-400 outline-none">
                     <option>Whole Blood</option>
                     <option>Platelets</option>
                     <option>Plasma</option>
                     <option>RBC</option>
                  </select>
               </div>
               <div className="flex gap-3 pt-4">
                  <Button variant="outline" className="flex-1" onClick={() => setIsAddModalOpen(false)}>Cancel</Button>
                  <Button variant="primary" className="flex-1" onClick={handleAddStock}>Verify & Add</Button>
               </div>
            </div>
          </motion.div>
        </div>
      )}

      {/* Group Quick Select */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 custom-scrollbar">
         {bloodGroups.map(group => (
           <button
            key={group}
            onClick={() => setSelectedGroup(group)}
            className={cn(
              "px-4 py-1.5 rounded-full text-xs font-display font-bold uppercase tracking-wider transition-all border",
              selectedGroup === group 
                ? "bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-600/20" 
                : "bg-navy-900 border-navy-800 text-gray-500 hover:text-gray-300"
            )}
           >
            {group}
           </button>
         ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        <AnimatePresence mode="popLayout">
          {filteredUnits.map((unit, index) => {
            const hoursRemaining = (new Date(unit.expiresAt).getTime() - time.getTime()) / (1000 * 60 * 60);
            const status = hoursRemaining < 2 ? 'critical' : hoursRemaining < 6 ? 'urgent' : hoursRemaining < 24 ? 'watch' : 'safe';
            
            return (
              <motion.div
                key={unit.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.2 }}
              >
                <Card className={cn(
                  "relative group transition-all duration-300 hover:border-navy-700",
                  status === 'critical' && "border-critical/30 bg-critical/5",
                  status === 'urgent' && "border-urgent/30 bg-urgent/5"
                )}>
                  <div className="p-4">
                    <div className="flex justify-between items-start mb-4">
                      <div className={cn(
                        "w-12 h-12 rounded-lg flex flex-col items-center justify-center border",
                        status === 'critical' ? "bg-critical/20 border-critical/30" : "bg-navy-950 border-navy-800"
                      )}>
                        <span className={cn("text-lg font-display font-black", status === 'critical' ? "text-critical" : "text-blue-400")}>{unit.bloodGroup}</span>
                        <span className="text-[7px] font-mono text-gray-500 uppercase leading-none">{unit.component.split(' ')[0]}</span>
                      </div>
                      <div className="flex flex-col items-end">
                        <Badge label={unit.id} variant="default" className="bg-transparent border-none p-0 text-[9px] mb-1 opacity-50" />
                        <Badge 
                          label={Math.floor(hoursRemaining) + "H " + Math.floor((hoursRemaining % 1) * 60) + "M"} 
                          variant={status} 
                          dot={status === 'critical'}
                        />
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <p className="text-[10px] font-mono text-gray-500 uppercase tracking-tighter">Current Facility</p>
                        <p className="text-sm font-medium text-gray-300">AIIMS Delhi</p>
                      </div>
                      
                      <div className="flex justify-between items-end">
                        <div className="flex-1">
                          <p className="text-[10px] font-mono text-gray-500 uppercase tracking-tighter">Routing Priority</p>
                          <div className="w-full h-1 bg-navy-800 rounded-full mt-1.5 overflow-hidden">
                             <div 
                              className={cn(
                                "h-full rounded-full transition-all duration-1000",
                                unit.routingScore > 80 ? "bg-urgent" : unit.routingScore > 50 ? "bg-watch" : "bg-safe"
                              )} 
                              style={{ width: `${unit.routingScore}%` }} 
                             />
                          </div>
                        </div>
                        <span className="text-[10px] font-mono text-gray-400 ml-3">{unit.routingScore}%</span>
                      </div>
                    </div>

                    <div className="mt-5 pt-4 border-t border-navy-800/50 flex gap-2">
                       <Button variant="outline" className="flex-1 py-1.5 text-xs h-8">Details</Button>
                       <Button variant={status === 'critical' || status === 'urgent' ? 'danger' : 'secondary'} className="flex-1 py-1.5 text-xs h-8">
                        {status === 'critical' || status === 'urgent' ? 'Route Now' : 'Allocate'}
                       </Button>
                    </div>
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default Inventory;
