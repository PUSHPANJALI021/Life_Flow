import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { ShieldCheck, Users, Map as MapIcon, Database, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { Card, Badge, Button } from '../components/ui/UIs';
import { cn } from '../utils/utils';

const wastageData = [
  { month: 'JAN', rate: 4.2 },
  { month: 'FEB', rate: 3.8 },
  { month: 'MAR', rate: 3.1 },
  { month: 'APR', rate: 2.4 },
  { month: 'MAY', rate: 1.8 },
];

const imbalanceData = [
  { group: 'O+', diff: 12 },
  { group: 'O-', diff: -8 },
  { group: 'A+', diff: 15 },
  { group: 'A-', diff: -3 },
  { group: 'B+', diff: 24 },
  { group: 'B-', diff: -5 },
  { group: 'AB+', diff: 7 },
  { group: 'AB-', diff: -2 },
];

const COLORS = ['#10B981', '#EF4444', '#3B82F6', '#F59E0B'];

const Admin = () => {
  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <div>
           <h1 className="text-3xl font-display font-bold">Governance Dashboard</h1>
           <p className="text-gray-500 font-mono text-xs uppercase tracking-widest mt-1">Nodal performance & infrastructure health</p>
        </div>
        <div className="flex bg-navy-900 border border-navy-800 rounded-lg p-1">
           <Button variant="outline" className="h-8 text-[10px] font-mono border-none">EXPORT REPORT</Button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Units Saved / Mo', value: '412', trend: '+14%', color: 'text-safe' },
          { label: 'Wastage Rate', value: '1.8%', trend: '-22%', color: 'text-safe' },
          { label: 'Avg Transit Time', value: '18.4m', trend: '-8%', color: 'text-blue-400' },
          { label: 'Active Nodes', value: '312', trend: '+4', color: 'text-safe' },
        ].map(k => (
          <div key={k.label} className="bg-navy-900 border border-navy-800 p-4 rounded-xl">
             <p className="text-[10px] font-mono text-gray-500 uppercase tracking-tighter mb-1">{k.label}</p>
             <div className="flex items-end justify-between">
                <span className="text-2xl font-display font-bold text-gray-200">{k.value}</span>
                <span className={cn("text-[10px] font-mono font-bold flex items-center gap-0.5", k.color)}>
                   {k.trend.startsWith('+') ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                   {k.trend}
                </span>
             </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
         {/* Wastage Trend */}
         <Card title="Wastage Reduction Trend" subtitle="Percentage of units expired across network">
            <div className="h-64 mt-4 px-2">
               <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={wastageData}>
                     <CartesianGrid strokeDasharray="3 3" stroke="#1E2A3A" vertical={false} />
                     <XAxis 
                        dataKey="month" 
                        stroke="#4B5563" 
                        fontSize={10} 
                        fontFamily="IBM Plex Mono" 
                        axisLine={false}
                        tickLine={false}
                     />
                     <YAxis 
                        stroke="#4B5563" 
                        fontSize={10} 
                        fontFamily="IBM Plex Mono" 
                        axisLine={false} 
                        tickLine={false} 
                        unit="%"
                     />
                     <Tooltip 
                        contentStyle={{ backgroundColor: '#111827', border: '1px solid #1E2A3A' }}
                        itemStyle={{ fontSize: '10px', fontFamily: 'IBM Plex Mono' }}
                     />
                     <Line 
                        type="monotone" 
                        dataKey="rate" 
                        stroke="#10B981" 
                        strokeWidth={4} 
                        dot={{ r: 4, fill: '#10B981', strokeWidth: 0 }}
                        activeDot={{ r: 6, strokeWidth: 0 }}
                     />
                  </LineChart>
               </ResponsiveContainer>
            </div>
         </Card>

         {/* Imbalance Chart */}
         <Card title="Regional Stock Imbalance" subtitle="Deviation from optimal safety levels">
            <div className="h-64 mt-4 px-2">
               <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={imbalanceData}>
                     <CartesianGrid strokeDasharray="3 3" stroke="#1E2A3A" vertical={false} />
                     <XAxis 
                        dataKey="group" 
                        stroke="#4B5563" 
                        fontSize={10} 
                        fontFamily="IBM Plex Mono" 
                        axisLine={false}
                        tickLine={false}
                     />
                     <YAxis 
                        stroke="#4B5563" 
                        fontSize={10} 
                        fontFamily="IBM Plex Mono" 
                        axisLine={false} 
                        tickLine={false} 
                     />
                     <Tooltip 
                        contentStyle={{ backgroundColor: '#111827', border: '1px solid #1E2A3A' }}
                        cursor={{ fill: '#1E2A3A' }}
                     />
                     <Bar dataKey="diff">
                        {imbalanceData.map((entry, index) => (
                           <Cell key={`cell-${index}`} fill={entry.diff > 0 ? '#3B82F6' : '#EF4444'} />
                        ))}
                     </Bar>
                  </BarChart>
               </ResponsiveContainer>
            </div>
            <div className="px-6 flex justify-between pb-2">
               <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-blue-500" />
                  <span className="text-[10px] font-mono text-gray-500 uppercase">Surplus Detected</span>
               </div>
               <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-urgent" />
                  <span className="text-[10px] font-mono text-gray-500 uppercase">Deficit Threshold</span>
               </div>
            </div>
         </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
         <Card title="System Resources" className="h-full">
            <div className="p-4 space-y-4">
               {[
                  { icon: Users, label: 'Verified Personnel', val: '1,240' },
                  { icon: MapIcon, label: 'Geo-Nodes Map Status', val: 'SYNCED' },
                  { icon: Database, label: 'Database Replication', val: '99.9%' },
                  { icon: ShieldCheck, label: 'Protocol Integrity', val: 'HIGH' },
               ].map(r => (
                  <div key={r.label} className="flex items-center justify-between p-3 bg-navy-950/50 rounded-lg border border-navy-800">
                     <div className="flex items-center gap-3">
                        <r.icon size={16} className="text-blue-400" />
                        <span className="text-xs font-medium text-gray-400">{r.label}</span>
                     </div>
                     <span className="text-xs font-mono font-bold text-gray-200">{r.val}</span>
                  </div>
               ))}
            </div>
         </Card>

         <Card title="Top Performing Facilities" className="lg:col-span-2">
            <div className="overflow-x-auto">
               <table className="w-full text-left border-collapse">
                  <thead className="bg-navy-950/50">
                     <tr>
                        <th className="px-4 py-3 text-[10px] font-mono text-gray-500 uppercase">Facility Name</th>
                        <th className="px-4 py-3 text-[10px] font-mono text-gray-500 uppercase">Response Time</th>
                        <th className="px-4 py-3 text-[10px] font-mono text-gray-500 uppercase">Saving Rate</th>
                        <th className="px-4 py-3 text-[10px] font-mono text-gray-500 uppercase">Status</th>
                     </tr>
                  </thead>
                  <tbody className="divide-y divide-navy-800">
                     {[
                        { name: 'AIIMS Delhi', time: '12.4m', rate: '99.2%', status: 'Elite' },
                        { name: 'Holy Family Hospital', time: '14.1m', rate: '98.5%', status: 'Elite' },
                        { name: 'Red Cross Blood Bank', time: '11.8m', rate: '97.2%', status: 'Stable' },
                        { name: 'Safdarjung Hospital', time: '15.6m', rate: '96.8%', status: 'Stable' },
                     ].map(f => (
                        <tr key={f.name} className="hover:bg-navy-800/30 transition-colors">
                           <td className="px-4 py-3 text-xs font-bold text-gray-200">{f.name}</td>
                           <td className="px-4 py-3 text-xs font-mono text-blue-400">{f.time}</td>
                           <td className="px-4 py-3 text-xs font-mono text-safe">{f.rate}</td>
                           <td className="px-4 py-3"><Badge label={f.status} variant="safe" /></td>
                        </tr>
                     ))}
                  </tbody>
               </table>
            </div>
         </Card>
      </div>
    </div>
  );
};

export default Admin;
