import React from 'react';
import { motion } from 'motion/react';
import { cn } from '../utils/utils';
import { Card, Badge, Button } from '../components/ui/UIs';
import { ChevronRight } from 'lucide-react';

import MapView from '../components/map/MapView';
import { useAppContext } from '../context/AppContext';

const Dashboard = () => {
  const { units, alerts, transfers, time } = useAppContext();

  // Derived stats
  const expiringSoonCount = units.filter(u => {
    const hoursRemaining = (new Date(u.expiresAt).getTime() - time.getTime()) / (1000 * 60 * 60);
    return hoursRemaining < 6;
  }).length;

  const criticalUnits = units
    .filter(u => (new Date(u.expiresAt).getTime() - time.getTime()) / (1000 * 60 * 60) < 6)
    .sort((a,b) => new Date(a.expiresAt).getTime() - new Date(b.expiresAt).getTime())
    .slice(0, 5);

  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-display font-bold">Command Center</h1>
          <p className="text-gray-500 font-mono text-xs uppercase tracking-widest mt-1">Hinterland Grid: South-East Delhi Operations</p>
        </div>
        <div className="text-right">
           <p className="text-xs font-mono text-gray-400">SESSION TIME</p>
           <p className="text-xl font-mono font-bold text-blue-400">{time.toLocaleTimeString('en-IN')}</p>
        </div>
      </header>
      
      {/* KPI Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {[
          { label: 'Active Units', value: units.length, change: '+12%', color: 'text-blue-400' },
          { label: 'Expiring <6h', value: expiringSoonCount, change: '+2', color: 'text-urgent' },
          { label: 'Emergency Shortages', value: alerts.filter(a => a.type === 'critical').length, change: 'ACTIVE', color: 'text-critical' },
          { label: 'Transfers In Progress', value: transfers.length, change: 'TRACKING', color: 'text-indigo-400' },
          { label: 'Units Saved', value: 124, change: '+14%', color: 'text-safe' },
        ].map((kpi, i) => (
          <motion.div 
            key={kpi.label}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.1 }}
            className="bg-navy-900 border border-navy-800 p-4 rounded-xl relative overflow-hidden"
          >
            <div className="flex flex-col">
              <span className="text-[10px] font-mono text-gray-500 uppercase tracking-tighter">{kpi.label}</span>
              <div className="flex items-baseline justify-between mt-1">
                <span className={cn("text-2xl font-display font-bold", kpi.color)}>{kpi.value}</span>
                <span className="text-[9px] font-mono font-semibold tracking-tighter text-gray-500">{kpi.change}</span>
              </div>
            </div>
            <div className={cn("absolute bottom-0 left-0 h-1 w-full opacity-20", kpi.color.replace('text-', 'bg-'))} />
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Main Map */}
        <div className="lg:col-span-8 h-[500px]">
          <Card title="Regional Operations Map" subtitle="Live tracking of facilities & assets" className="h-full">
             <div className="w-full h-full overflow-hidden">
                <MapView />
             </div>
          </Card>
        </div>

        {/* Priority Queue */}
        <div className="lg:col-span-4 h-[500px]">
          <Card title="Critical Priority Queue" subtitle="Units requiring immediate routing" className="h-full">
            <div className="p-4 space-y-3 overflow-y-auto h-full pb-20 custom-scrollbar">
               {criticalUnits.map(unit => {
                  const hoursRemaining = (new Date(unit.expiresAt).getTime() - time.getTime()) / (1000 * 60 * 60);
                  const minutesRemaining = Math.floor((hoursRemaining % 1) * 60);
                  const h = Math.floor(hoursRemaining);
                  const timer = `${String(h).padStart(2, '0')}:${String(minutesRemaining).padStart(2, '0')}:${String(Math.floor(Math.random() * 60)).padStart(2, '0')}`;
                  
                  return (
                    <motion.div 
                      key={unit.id} 
                      layout
                      className="bg-navy-950/50 border border-navy-800 p-3 rounded-lg flex items-center justify-between group hover:border-urgent transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded bg-blood-red/10 border border-blood-red/20 flex flex-col items-center justify-center">
                            <span className="text-xs font-bold text-blood-red">{unit.bloodGroup}</span>
                            <span className="text-[7px] font-mono text-gray-500 uppercase leading-none mt-0.5">{unit.component.split(' ')[0]}</span>
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                                <span className="text-xs font-bold text-gray-200">FAC-001</span>
                                <Badge label={timer} variant={h < 2 ? "critical" : "urgent"} />
                            </div>
                            <p className="text-[10px] text-gray-500 font-mono mt-0.5 uppercase tracking-tighter">Routing Score: {unit.routingScore}%</p>
                          </div>
                      </div>
                      <ChevronRight size={16} className="text-gray-600 group-hover:text-urgent" />
                    </motion.div>
                  );
               })}
               
               <div className="absolute bottom-4 left-4 right-4">
                 <Button variant="danger" className="w-full py-3 font-display uppercase tracking-widest text-xs shadow-lg shadow-blood-red/20">
                    Emergency Dispatch
                 </Button>
               </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Alert Feed */}
      <Card title="Live Alert Stream" subtitle="Auto-scrolling operational events">
         <div className="h-16 flex items-center px-4 overflow-hidden gap-8">
            <div className="flex-none flex items-center gap-2">
               <div className="w-2 h-2 rounded-full bg-safe animate-pulse" />
               <span className="text-[10px] text-gray-400 font-mono tracking-widest uppercase">System Feed</span>
            </div>
            <div className="flex-1 whitespace-nowrap overflow-hidden text-sm text-gray-300">
               <motion.div 
                className="flex items-center gap-12"
                animate={{ x: [0, -2000] }} 
                transition={{ duration: 60, repeat: Infinity, ease: 'linear' }}
               >
                  {alerts.map(a => (
                    <div key={a.id} className="flex items-center gap-2">
                      <Badge label={a.type} variant={a.type} />
                      <span className="font-mono text-xs opacity-50">[{new Date(a.timestamp).toLocaleTimeString()}]</span>
                      <span className="font-medium">{a.message}</span>
                    </div>
                  ))}
               </motion.div>
            </div>
         </div>
      </Card>
    </div>
  );
};


export default Dashboard;
