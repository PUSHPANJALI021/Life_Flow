import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bell, AlertTriangle, Info, Clock, ExternalLink, ChevronRight, MessageSquare, Send, Zap } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { Card, Badge, Button } from '../components/ui/UIs';
import { cn } from '../utils/utils';

const Alerts = () => {
  const { alerts } = useAppContext();

  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <div>
           <h1 className="text-3xl font-display font-bold text-gray-100">Regional Alert Center</h1>
           <p className="text-gray-500 font-mono text-xs uppercase tracking-widest mt-1">Centralized operational escalation feed</p>
        </div>
        <div className="flex items-center gap-3">
           <div className="flex -space-x-2">
              {[1, 2, 3].map(i => (
                 <div key={i} className="w-8 h-8 rounded-full border-2 border-navy-950 bg-navy-800 flex items-center justify-center text-[10px] font-bold text-gray-400">
                    S{i}
                 </div>
              ))}
           </div>
           <Button variant="outline" className="h-10 text-xs">Manage Subscriptions</Button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[calc(100vh-220px)]">
        {/* Sidebar: Filters & Stats */}
        <div className="lg:col-span-1 space-y-6">
           <Card title="Signal Summary">
              <div className="p-4 space-y-4">
                 {[
                    { label: 'Critical Errors', count: alerts.filter(a => a.type === 'critical').length, color: 'text-critical' },
                    { label: 'Urgent Alerts', count: alerts.filter(a => a.type === 'urgent').length, color: 'text-urgent' },
                    { label: 'System Info', count: alerts.filter(a => a.type === 'info').length, color: 'text-blue-400' },
                 ].map(stat => (
                    <div key={stat.label} className="flex items-center justify-between">
                       <span className="text-xs font-medium text-gray-400">{stat.label}</span>
                       <span className={cn("text-xs font-mono font-bold", stat.color)}>{stat.count}</span>
                    </div>
                 ))}
              </div>
           </Card>

           <div className="space-y-2">
              <h3 className="text-[10px] font-mono text-gray-500 uppercase tracking-widest px-1 font-bold">Quick Actions</h3>
              <Button variant="danger" className="w-full justify-start h-12 text-xs font-display">
                 <AlertTriangle size={16} /> MASS ESCALATION (SMS)
              </Button>
              <Button variant="outline" className="w-full justify-start h-12 text-xs font-display">
                 <MessageSquare size={16} /> DEPLOY COORDINATORS
              </Button>
           </div>
        </div>

        {/* Main Feed */}
        <div className="lg:col-span-3 overflow-y-auto pr-2 custom-scrollbar space-y-4">
           <AnimatePresence mode="popLayout">
              {alerts.map((alert, i) => (
                <motion.div
                  key={alert.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className={cn(
                    "p-5 rounded-xl border flex gap-6 group transition-all duration-300",
                    alert.type === 'critical' ? "bg-critical/5 border-critical/30" : 
                    alert.type === 'urgent' ? "bg-urgent/5 border-urgent/30" : 
                    "bg-navy-900 border-navy-800"
                  )}
                >
                  <div className={cn(
                    "w-12 h-12 rounded-xl flex items-center justify-center shrink-0",
                    alert.type === 'critical' ? "bg-critical/20 text-critical" : 
                    alert.type === 'urgent' ? "bg-urgent/20 text-urgent" : 
                    "bg-blue-400/20 text-blue-400"
                  )}>
                    {alert.type === 'critical' || alert.type === 'urgent' ? <AlertTriangle size={24} /> : <Info size={24} />}
                  </div>

                  <div className="flex-1 space-y-2">
                     <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                           <Badge label={alert.type} variant={alert.type} />
                           <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">
                              {new Date(alert.timestamp).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}
                           </span>
                        </div>
                        <div className="flex items-center gap-1 text-[10px] font-mono text-gray-600 group-hover:text-gray-400 cursor-pointer">
                           <Clock size={12} />
                           {i === 0 ? '5 SEC AGO' : i === 1 ? '5 MIN AGO' : '15 MIN AGO'}
                        </div>
                     </div>

                     <h4 className="text-sm font-medium text-gray-200 leading-snug">{alert.message}</h4>
                     
                     {alert.actionRequired && (
                        <div className="bg-navy-950/50 rounded-lg p-3 border border-navy-800/50 mt-3">
                           <div className="flex items-center gap-2 mb-1">
                              <Zap className="text-watch" size={14} />
                              <span className="text-[10px] font-mono text-watch uppercase tracking-widest font-bold">Recommendation</span>
                           </div>
                           <p className="text-xs text-gray-400">{alert.actionRequired}</p>
                        </div>
                     )}

                     <div className="pt-4 flex items-center gap-3">
                        <Button variant="primary" className="h-8 py-0 text-[10px] font-display uppercase tracking-widest">
                           {alert.actionRequired ? 'EXECUTE ACTION' : 'ACKNOWLEDGE'}
                        </Button>
                        <Button variant="outline" className="h-8 py-0 px-3 text-[10px] font-display uppercase tracking-widest">
                           ESCALATE
                        </Button>
                        <div className="flex-1" />
                        <div className="flex items-center gap-2 text-[10px] font-mono text-gray-600 group-hover:text-blue-400 cursor-pointer transition-colors">
                           <ExternalLink size={12} />
                           VIEW SOURCE
                        </div>
                     </div>
                  </div>
                </motion.div>
              ))}
           </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default Alerts;
