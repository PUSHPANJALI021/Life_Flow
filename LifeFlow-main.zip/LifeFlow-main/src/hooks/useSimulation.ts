import { useState, useEffect, useCallback } from 'react';
import { mockBloodUnits, BloodUnit } from '../data/mockBloodUnits';
import { mockFacilities, Facility } from '../data/mockFacilities';
import { mockAlerts, Alert } from '../data/mockAlerts';
import { mockTransfers, Transfer } from '../data/mockTransfers';

export const useSimulation = () => {
  const [units, setUnits] = useState<BloodUnit[]>(mockBloodUnits);
  const [facilities, setFacilities] = useState<Facility[]>(mockFacilities);
  const [alerts, setAlerts] = useState<Alert[]>(mockAlerts);
  const [transfers, setTransfers] = useState<Transfer[]>(mockTransfers);
  const [time, setTime] = useState(new Date());

  const tick = useCallback(() => {
    setTime(new Date());

    // 1. Tick down expiry timers (Simulation only, real date handles it)
    // Actually our units have expiresAt which is a real date. 
    // We just need to trigger events based on that.

    // 2. Randomly trigger new alerts
    if (Math.random() > 0.95) {
      const randomFacility = facilities[Math.floor(Math.random() * facilities.length)];
      const newAlert: Alert = {
        id: `AL-${Date.now()}`,
        type: Math.random() > 0.7 ? 'urgent' : 'info',
        timestamp: new Date().toISOString(),
        message: `New demand spike detected at ${randomFacility.name}`,
        facilityId: randomFacility.id,
        bloodGroup: "B+"
      };
      setAlerts(prev => [newAlert, ...prev.slice(0, 19)]);
    }

    // 3. Update ambulance positions
    setTransfers(prev => prev.map(tr => {
      if (tr.status === 'in_transit') {
        const nextLat = tr.lat + (Math.random() - 0.5) * 0.005;
        const nextLng = tr.lng + (Math.random() - 0.5) * 0.005;
        return {
          ...tr,
          lat: nextLat,
          lng: nextLng,
          eta: Math.max(0, tr.eta - 1)
        };
      }
      return tr;
    }));
  }, [facilities]);

  useEffect(() => {
    const interval = setInterval(tick, 3000);
    return () => clearInterval(interval);
  }, [tick]);

  return { units, facilities, alerts, transfers, time, setUnits, setTransfers, setAlerts };
};
