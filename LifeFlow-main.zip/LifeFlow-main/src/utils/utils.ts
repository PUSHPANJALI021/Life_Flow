import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const formatTime = (date: Date) => {
  return date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
};

export const getExpiryStatus = (hoursRemaining: number) => {
  if (hoursRemaining < 2) return 'critical';
  if (hoursRemaining < 6) return 'urgent';
  if (hoursRemaining < 24) return 'watch';
  return 'safe';
};
