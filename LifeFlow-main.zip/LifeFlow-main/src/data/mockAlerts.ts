export interface Alert {
  id: string;
  type: 'info' | 'warning' | 'urgent' | 'critical';
  timestamp: string;
  message: string;
  facilityId: string;
  bloodGroup?: string;
  actionRequired?: string;
}

export const mockAlerts: Alert[] = [
  {
    id: "AL-001",
    type: "critical",
    timestamp: new Date().toISOString(),
    message: "Critical shortage of O- at Safdarjung Hospital. Current stock: 0 units.",
    facilityId: "FAC-002",
    bloodGroup: "O-",
    actionRequired: "Diverting near-expiry unit BU-2024-012 from AIIMS."
  },
  {
    id: "AL-002",
    type: "urgent",
    timestamp: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
    message: "4 units of A+ expiring in < 2 hours at Holy Family Hospital.",
    facilityId: "FAC-005",
    bloodGroup: "A+",
    actionRequired: "Approve transfer to Max Hospital."
  },
  {
    id: "AL-003",
    type: "warning",
    timestamp: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
    message: "B+ demand expected to spike at AIIMS due to scheduled trauma cases.",
    facilityId: "FAC-001",
    bloodGroup: "B+",
  }
];
