export type BloodGroup = "O+" | "O-" | "A+" | "A-" | "B+" | "B-" | "AB+" | "AB-";
export type BloodComponent = "Whole Blood" | "Platelets" | "Plasma" | "RBC";
export type BloodUnitStatus = "available" | "reserved" | "in_transfer" | "used";

export interface BloodUnit {
  id: string;
  bloodGroup: BloodGroup;
  component: BloodComponent;
  collectedAt: string;
  expiresAt: string;
  facilityId: string;
  status: BloodUnitStatus;
  routingScore: number;
  districtId: string;
}

const bloodGroups: BloodGroup[] = ["O+", "O-", "A+", "A-", "B+", "B-", "AB+", "AB-"];
const components: BloodComponent[] = ["Whole Blood", "Platelets", "Plasma", "RBC"];
const facilityIds = ["FAC-001", "FAC-002", "FAC-003", "FAC-004", "FAC-005", "FAC-006"];

export const generateMockUnits = (count: number): BloodUnit[] => {
  const units: BloodUnit[] = [];
  const now = new Date();

  for (let i = 0; i < count; i++) {
    const collectedAt = new Date(now.getTime() - Math.random() * 10 * 24 * 60 * 60 * 1000); // collected in last 10 days
    const expiresAt = new Date(now.getTime() + (Math.random() * 72) * 60 * 60 * 1000); // expires in next 0-72 hours
    
    units.push({
      id: `BU-2024-${String(i + 1).padStart(3, '0')}`,
      bloodGroup: bloodGroups[Math.floor(Math.random() * bloodGroups.length)],
      component: components[Math.floor(Math.random() * components.length)],
      collectedAt: collectedAt.toISOString(),
      expiresAt: expiresAt.toISOString(),
      facilityId: facilityIds[Math.floor(Math.random() * facilityIds.length)],
      status: "available",
      routingScore: Math.floor(Math.random() * 100),
      districtId: "DL-01"
    });
  }
  return units;
};

export const mockBloodUnits = generateMockUnits(100);
