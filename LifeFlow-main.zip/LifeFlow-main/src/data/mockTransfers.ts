export interface Transfer {
  id: string;
  unitId: string;
  bloodGroup: string;
  sourceFacilityId: string;
  destinationFacilityId: string;
  status: 'recommended' | 'approved' | 'dispatched' | 'in_transit' | 'delivered';
  eta: number; // minutes
  ambulanceId: string;
  lat: number;
  lng: number;
  path: [number, number][]; // coordinates for movement
}

export const mockTransfers: Transfer[] = [
  {
    id: "TR-001",
    unitId: "BU-2024-001",
    bloodGroup: "O+",
    sourceFacilityId: "FAC-003",
    destinationFacilityId: "FAC-004",
    status: "in_transit",
    eta: 12,
    ambulanceId: "AMB-101",
    lat: 28.5800,
    lng: 77.2100,
    path: [[28.5672, 77.2100], [28.5284, 77.2185]]
  }
];
