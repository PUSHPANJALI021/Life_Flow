export interface Facility {
  id: string;
  name: string;
  type: 'hospital' | 'blood_bank' | 'phc' | 'storage_centre';
  lat: number;
  lng: number;
  district: string;
  state: string;
  stockHealth: 'stable' | 'low' | 'critical';
  shortageGroups: string[];
  surplusGroups: string[];
  capacity: number;
  currentUnits: number;
}

export const mockFacilities: Facility[] = [
  {
    id: "FAC-001",
    name: "AIIMS Delhi",
    type: "hospital",
    lat: 28.5672,
    lng: 77.2100,
    district: "New Delhi",
    state: "Delhi",
    stockHealth: "stable",
    shortageGroups: ["AB-", "B-"],
    surplusGroups: ["O+"],
    capacity: 500,
    currentUnits: 312
  },
  {
    id: "FAC-002",
    name: "Safdarjung Hospital",
    type: "hospital",
    lat: 28.5700,
    lng: 77.2085,
    district: "New Delhi",
    state: "Delhi",
    stockHealth: "low",
    shortageGroups: ["O-", "A-"],
    surplusGroups: ["B+"],
    capacity: 400,
    currentUnits: 150
  },
  {
    id: "FAC-003",
    name: "Red Cross Blood Bank",
    type: "blood_bank",
    lat: 28.6139,
    lng: 77.2090,
    district: "Central Delhi",
    state: "Delhi",
    stockHealth: "stable",
    shortageGroups: [],
    surplusGroups: ["A+", "O+", "B+"],
    capacity: 1000,
    currentUnits: 750
  },
  {
    id: "FAC-004",
    name: "Max Super Specialty Hospital",
    type: "hospital",
    lat: 28.5284,
    lng: 77.2185,
    district: "South Delhi",
    state: "Delhi",
    stockHealth: "critical",
    shortageGroups: ["O+", "O-", "B+"],
    surplusGroups: [],
    capacity: 300,
    currentUnits: 45
  },
  {
    id: "FAC-005",
    name: "Holy Family Hospital",
    type: "hospital",
    lat: 28.5615,
    lng: 77.2721,
    district: "South East Delhi",
    state: "Delhi",
    stockHealth: "stable",
    shortageGroups: ["AB+"],
    surplusGroups: ["A-"],
    capacity: 250,
    currentUnits: 180
  },
  {
    id: "FAC-006",
    name: "Fortis Escorts Heart Institute",
    type: "hospital",
    lat: 28.5592,
    lng: 77.2743,
    district: "South East Delhi",
    state: "Delhi",
    stockHealth: "low",
    shortageGroups: ["B+"],
    surplusGroups: ["AB-"],
    capacity: 200,
    currentUnits: 80
  }
];
